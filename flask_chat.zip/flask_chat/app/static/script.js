function abrirModalRAG() {
    fetch('/api/rag')
    .then(res => res.text())
    .then(data => {
        document.getElementById('ragContent').textContent = data;
        document.getElementById('ragModal').style.display = 'block';
    });
}

function abrirModalJuiz() {
    fetch('/api/juiz')
    .then(res => res.json())
    .then(data => {
        document.getElementById('juizContent').textContent = data.resultado;
        document.getElementById('juizModal').style.display = 'block';
    });
}

function fecharModal(id) {
    document.getElementById(id).style.display = 'none';
}