from flask import Blueprint, render_template, request, jsonify
from datetime import datetime
import os
import difflib
from dotenv import load_dotenv

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.agents import initialize_agent, AgentType
from langchain.memory import ConversationBufferMemory
from langchain.tools import Tool
from langchain.prompts import ChatPromptTemplate

# Configuração do blueprint
bp = Blueprint("chat", __name__)

# Variáveis de log
LOG = "logs/conversa.log"
LOG_ATENDENTE = "logs/atendente.log"
LOG_USUARIO = "logs/usuario.log"

# Carregar .env e configurar LLM
load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")
llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", google_api_key=api_key)

# Prompt do juiz
prompt_juiz_template = """Você é um juiz de IA. Avalie se a seguinte afirmação é correta (SIM/NAO) e justifique: "{afirmacao}"."""
prompt_juiz = ChatPromptTemplate.from_template(prompt_juiz_template)

# Funções utilitárias
def registrar_log(origem, mensagem):
    os.makedirs("logs", exist_ok=True)
    if mensagem.strip():
        with open(LOG, "a") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] [{origem.upper()}] {mensagem.strip()}\n")
    if origem == "atendente":
        with open(LOG_ATENDENTE, "a") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {mensagem.strip()}\n")
    elif origem == "usuário":
        with open(LOG_USUARIO, "a") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {mensagem.strip()}\n")


def carregar_historico():
    if not os.path.exists(LOG):
        return []
    with open(LOG, "r") as f:
        linhas = list(f.readlines())
    coloridas = []
    for l in linhas:
        if "[USUÁRIO]" in l:
            cor = "red"
        elif "[ATENDENTE]" in l:
            cor = "blue"
        else:
            cor = "black"
        coloridas.append(f'<font color="{cor}">{l.strip()}</font>')
    return coloridas


def carregar_conversa():
    return open(LOG).read() if os.path.exists(LOG) else ""


def consultar_rag(pergunta):
    base = []
    for nome in os.listdir("documentos"):
        if nome.endswith(".txt"):
            with open(f"documentos/{nome}") as f:
                base.append(f.read())
    texto = "\n".join(base)
    sentencas = texto.split(". ")
    melhores = difflib.get_close_matches(pergunta, sentencas, n=3, cutoff=0.4)
    return "\n".join(melhores)


def avaliar_conversa(conversa):
    try:
        # Incluir a conversa real no prompt
        afirmacao = (
            "Abaixo está uma conversa entre um atendente de IA e um usuário. "
            "Avalie se ela contém informações factuais, se há possíveis alucinações "
            "ou afirmações incorretas. Seja objetivo e justifique com base na conversa.\n\n"
            f"{conversa}"
        )

        input_juiz = prompt_juiz.format(afirmacao=afirmacao)
        output = llm.invoke(input_juiz)
        return output.content

    except Exception as e:
        return f"Ocorreu um erro ao executar o juiz: {e}"


# Rotas

@bp.route("/")
def home():
    if os.path.exists(LOG):
        os.remove(LOG)  # limpa o histórico ao acessar a tela principal
    return render_template("index.html")


@bp.route("/usuario", methods=["GET", "POST"])
def usuario():
    if request.method == "POST":
        if "enviar" in request.form:
            registrar_log("usuário", request.form["mensagem"])
        elif "encerrar" in request.form:
            registrar_log("usuário", "CONVERSA ENCERRADA PELO USUÁRIO")
    return render_template("usuario.html", historico=carregar_historico())


@bp.route("/atendente", methods=["GET", "POST"])
def atendente():
    if request.method == "POST":
        if "enviar" in request.form:
            registrar_log("atendente", request.form["mensagem"])
        elif "encerrar" in request.form:
            registrar_log("atendente", "CONVERSA ENCERRADA PELO ATENDENTE")
    return render_template("atendente.html", historico=carregar_historico())


@bp.route("/api/rag")
def api_rag():
    contexto = carregar_conversa()[-500:]
    resultado = consultar_rag(contexto)
    return resultado


@bp.route("/api/juiz")
def api_juiz():
    conversa = carregar_conversa()
    resultado = avaliar_conversa(conversa)
    return jsonify({"resultado": resultado})
